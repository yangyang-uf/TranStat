
pop.gen <- function(cases, demo, idx.cut.day, contact.cut.day, bias.base, bias.cut.day, bias.span, shift, path, type)
{
   #cases <- salvado; demo <- NULL; contact.cut.day<- 100
   #shift <- 50; idx.cut.day <- 10; bias.cut.day<-40; bias.span<-14
   ## correct for under-reporting
   n <- nrow(cases)
   if(is.null(bias.cut.day))
   {
      rescale <- rep(1,n)
   } else
   {   
      lower <- bias.cut.day
      upper <- bias.cut.day + bias.span
      rescale <- rep(0,n)
      rescale[cases$day < lower] <- bias.base
      k<-which(cases$day >= lower & cases$day <= upper)
      if(length(k) > 0)  rescale[k] <- bias.base + (1-bias.base) * (cases$day[k] - lower)/(upper - lower)
      rescale[cases$day > upper] <- 1
   }
   pop <- cbind(1:n, rep(0,n), rep(0,n), rep(1,n), rep(1,n), cases$day + shift, rep(0,n), rep(-1,n), 
          as.numeric(cases$day <= idx.cut.day),  rep(0,n), rep(0,n), cases$count/rescale, rep(0,n))
   colnames(pop) <- c('id', 'community', 'preimm', 'inf', 'sym', 'day_ill', 'exit', 'day_exit', 'idx', 'u_mode', 'q_mode', 'weight', 'ignore')
   if(type=='stratify')
   {
      sum.cases <- aggregate(count~gender+child+senior, data=cases, FUN='sum')
      if(!is.null(demo))
      {
         escapes <- merge(demo, sum.cases, by=c('gender', 'child','senior'))
      }  else
      {
         escapes <-  sum.cases
         escape$total <-  escapes$count * 50
      }         
      escapes$n_esc <- escapes$total - escapes$count
      k<-which(escapes$n_esc < 0)
      if(length(k)>0)  escapes$n_esc[k] <- 0
      m<-nrow(escapes)
      pop <- rbind(pop, cbind(n+(1:m), rep(0,m), rep(0,m), rep(0,m), rep(0,m), rep(-1,m), rep(0,m), rep(-1,m), 
                   rep(0,m),  rep(0,m), rep(0,m), escapes$n_esc, rep(0,m)))
      covariate <- data.frame(1:(n+m), c(cases$gender, escapes$gender), c(cases$child, escapes$child), c(cases$senior, escapes$senior))
      colnames(covariate) <- c('id', 'gender', 'child', 'senior')      
      covariate$id <- covariate$id - 1   
   }  else
   {
      if(!is.null(demo))
      {
         n.escapes <- sum(demo$total) - sum(cases$count)
      }  else
      {
         n.escapes <- sum(cases$count) * (50 - 1)
      }   
      if(n.escapes < 0)  n.escapes<-0
      pop <- rbind(pop, c(n+1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, n.escapes, 0))
      covariate <- NULL      
   }
   pop <- as.data.frame(pop)
   pop$id <- pop$id - 1   
   community <- data.frame(id=0, day_start=1, day_stop=max(cases$day + shift))
   write.table(pop, file = paste(path, 'pop.dat', sep=''), append = FALSE, sep = " ",  row.names = FALSE, col.names = FALSE)
   write.table(community, file = paste(path, 'community.dat', sep=''), append = FALSE, sep = " ",  row.names = FALSE, col.names = FALSE)
   if(!is.null(contact.cut.day))
   {
      p2p.contact <- rbind(c(0, min(cases$day + shift), contact.cut.day+shift, 0, 0, 0), c(0, contact.cut.day+shift+1, max(cases$day + shift), 1, 0, 0))      
      write.table(p2p.contact, file = paste(path, 'p2p_contact.dat', sep=''), append = FALSE, sep = " ",  row.names = FALSE, col.names = FALSE)
   }   
   if(!is.null(covariate))  write.table(covariate, file = paste(path, 'time_ind_covariate.dat', sep=''), append = FALSE, sep = " ",  row.names = FALSE, col.names = FALSE)
}      

fill.dates <- function(cases)
{ 
   cases.sort <- cases[order(cases$date_onset), ]
   tmp.date<-tmp.day<-NULL
   for(i in 2:nrow(cases))
   {
      d <- as.numeric(cases.sort$date_onset[i]-cases.sort$date_onset[i-1])
      if(d>1)
      {
         for(j in 1:(d-1))
         {
            tmp.date <- c(tmp.date, cases.sort$date_onset[i-1]+j)
            tmp.day <- c(tmp.day, cases.sort$day[i-1]+j)
         }
      }
   }
   if(length(tmp.date) > 0)
   {
      data.tmp<-data.frame(tmp.date, rep(0,length(tmp.date)), tmp.day)
      colnames(data.tmp) <- c('date_onset', 'count', 'day')
      data.tmp$date_onset <- as.Date(data.tmp$date_onset, origin = "1970-01-01")
      data.new <- rbind(cases, data.tmp)
      data.new <- data.new[order(data.new$date_onset),]
      return(data.new)
   }  else  return(cases.sort)
}

plot.epicurve <- function(cases, main.text)
{
   #cases<-girardot; main.text<-'Girardot, Columbia'
   tmp <- fill.dates(cases)
   x<-1:nrow(tmp)
   x<-c(x-0.5, x+0.5)
   k<-order(x)
   x<-x[k]
   y<-rep(tmp$count,each=2)
   plot(x,y, ylim=c(0, max(y)), type='l', lty=1, lwd=1.5, xlab='Day', ylab='Case Number')
}   

plot.R0 <- function(cases, R0.Di, R0.Tri, shift, x.tick, x.value, cap.quantile=0.9)
{
   if(FALSE)
   {
      R0 <- read.table('C:/research/TranStat/v5/girardot/overall/output_R0_1.txt', header=FALSE)
      colnames(R0)<-c('inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
      R0 <- subset(R0, day >= 80)
      shift<-50
      cases<-girardot
   }
   #R0.max<-max(R0.Di$upper, R0.Tri$upper)
   R0.max<-as.numeric(quantile(c(R0.Di$upper, R0.Tri$upper), probs=cap.quantile))
   y <- c(R0.Di$lower, R0.Di$est, R0.Di$upper, R0.Tri$lower, R0.Tri$est, R0.Tri$upper)
   y.tick<-pretty(y[y<R0.max])
   y.value<-as.character(signif(y.tick,2))

   cases$day <- cases$day + shift
   id.inc <- unique(R0$inc)
   id.inf <- unique(R0$inf)
   inc.name<-c('Short', 'Medium', 'Long')
   inc.value <- c(4.3, 5, 5.7)
   inf.name<-c('Short', 'Medium', 'Long')
   inf.value <- c(14.5, 17, 20.5)
   par(mfrow=c(3,3), mar = c(6, 4, 4, 2) + 0.1, xpd=F)
   for(i in 1:length(id.inc))
   {
      for(j in 1:length(id.inf))
      {
         par(mar = c(6, 4, 4, 2) + 0.1, xpd=F)
         sub.R0 <- subset(R0.Di, inc==id.inc[i] & inf==id.inf[j], select=c(day, est, lower, upper))
         tmp <- fill.dates(cases)
         tmp <- merge(tmp, sub.R0, by='day', all.x=TRUE)
         x<-tmp$day
         x.base<-c(x-0.5, x+0.5)
         k<-order(x.base)
         x.base<-x.base[k]
         y<-rep(tmp$count,each=2)
         plot(x.base,y, bty='n', ylim=c(0, max(y)), type='l', lty=1, lwd=1.5, xaxt='n', xlab='', ylab='',
              main=paste('Mean Serial Interval = ', inc.value[i]+inf.value[j], ' Days', sep=''))
         mtext('Case Number', side = 2, line = -2, outer = F, adj = 0.5, padj = 0, cex = 1.0)
         axis(1, at=x.tick, labels=F, col=1)
         mtext('Date', side = 1, line = 3, outer = F, adj = 0.5, padj = 0, cex = 0.8)
         text(x.tick, par("usr")[3]-max(y)/15, srt=30, adj=1, labels=x.value, xpd=T, cex=0.8)
         par(new=TRUE)
         plot(sub.R0$day, sub.R0$est, bty='n', type='l', lwd=2, col='red', xlim=range(x.base), xaxt='n', xlab='', ylim=c(0, R0.max), yaxt='n', ylab='') 
         #points(sub.R0$day, sub.R0$lower, col='red', cex=0.2)
         #points(sub.R0$day, sub.R0$upper, col='red', cex=0.2)
         lines(sub.R0$day, sub.R0$lower, lwd=2, lty=3, col='red')
         lines(sub.R0$day, sub.R0$upper, lwd=2, lty=3, col='red')
         axis(4, at=y.tick, labels=y.value, col='red')
         mtext('Effective R', side = 4, line = -2, outer = F, adj = 0.5, padj = 0, cex = 1.0)
         abline(h=1, lty=2, col='red')
         sub.R0 <- subset(R0.Tri, inc==id.inc[i] & inf==id.inf[j], select=c(day, est, lower, upper))
         lines(sub.R0$day, sub.R0$est, lwd=2, lty=1, col='darkgreen') 
         #points(sub.R0$day, sub.R0$lower, col='darkgreen', cex=0.2)
         #points(sub.R0$day, sub.R0$upper, col='darkgreen', cex=0.2)
         lines(sub.R0$day, sub.R0$lower, lwd=2, lty=3, col='darkgreen')
         lines(sub.R0$day, sub.R0$upper, lwd=2, lty=3, col='darkgreen')
      }
   }
}

plot.effective.R0 <- function(cases, R0.Tri, fit, bias.base, bias.cut.day, bias.span, shift, day.growth.start, day.peak, x.tick, x.value, cap.quantile)
{
   #cases<-sanandres; cap.quantile<-1 
   upper <- R0.Tri$upper[!is.na(R0.Tri$upper) & R0.Tri$upper<Inf]
   R0.max<-as.numeric(quantile(upper, probs=cap.quantile, na.rm=TRUE))
   if(R0.max < max(R0.Tri$est) & max(R0.Tri$est)<Inf)  R0.max <- max(R0.Tri$est)
   y <- c(R0.Tri$lower, R0.Tri$est, R0.Tri$upper)
   y.tick<-pretty(y[y<R0.max])
   y.value<-as.character(signif(y.tick,2))

   n <- max(cases$day) - min(cases$day) + 1
   rescale <- data.frame(day=min(cases$day):max(cases$day), scale=rep(0,n))
   if(is.null(bias.cut.day))
   {
      rescale$scale <- rep(1,n)
   } else
   {   
      lower <- bias.cut.day
      upper <- bias.cut.day + bias.span
      rescale$scale[rescale$day < lower] <- bias.base
      k<-which(rescale$day >= lower & rescale$day <= upper)
      if(length(k) > 0)  rescale$scale[k] <- bias.base + (1-bias.base) * (rescale$day[k] - lower)/(upper - lower)
      rescale$scale[rescale$day > upper] <- 1
   }
   rescale$day <- rescale$day + shift
   my.fit <- merge(fit, rescale, by='day', all.x=TRUE, sort=FALSE)
   my.fit <- my.fit[order(my.fit$inc, my.fit$inf, my.fit$day), ]
   cases$day <- cases$day + shift
   id.inc <- unique(R0.Tri$inc)
   id.inf <- unique(R0.Tri$inf)
   inc.name<-c('Short', 'Medium', 'Long')
   inc.value <- c(4.3, 5, 5.7)
   inf.name<-c('Short', 'Medium', 'Long')
   inf.value <- c(14.5, 17, 20.5)
   par(mfrow=c(3,3), mar = c(6, 4, 4, 2) + 0.1, xpd=F)
   for(i in 1:length(id.inc))
   {
      for(j in 1:length(id.inf))
      {
         par(mar = c(6, 4, 4, 2) + 0.1, xpd=F)
         sub.R0 <- subset(R0.Tri, inc==id.inc[i] & inf==id.inf[j], select=c(day, est, lower, upper))
         sub.fit <- subset(my.fit, inc==id.inc[i] & inf==id.inf[j], select=c(day, at_risk, obs, pred, lower, upper, scale))
         tmp <- fill.dates(cases)
         tmp <- merge(tmp, sub.R0, by='day', all.x=TRUE)
         x<-tmp$day
         x.base<-c(x-0.5, x+0.5)
         k<-order(x.base)
         x.base<-x.base[k]
         y<-rep(tmp$count,each=2)
         plot(x.base,y, bty='n', ylim=c(0, max(c(y, sub.fit$upper * sub.fit$scale))), type='l', lty=1, lwd=1, col='darkgrey', xaxt='n', xlab='', ylab='',
              main=paste('Mean Serial Interval = ', inc.value[i]+inf.value[j], ' Days', sep=''))
         mtext('Case Number', side = 2, line = -2, outer = F, adj = 0.5, padj = 0, cex = 1.0)
         axis(1, at=x.tick, labels=F, col=1)
         mtext('Date', side = 1, line = 3, outer = F, adj = 0.5, padj = 0, cex = 0.8)
         text(x.tick, par("usr")[3]-max(y)/15, srt=30, adj=1, labels=x.value, xpd=T, cex=0.8)
         lines(sub.fit$day, sub.fit$pred * sub.fit$scale, lwd=2, lty=1, col='darkgreen') 
         lines(sub.fit$day, sub.fit$lower * sub.fit$scale, lwd=1, lty=2, col='darkgreen')
         lines(sub.fit$day, sub.fit$upper * sub.fit$scale, lwd=1, lty=2, col='darkgreen')
         par(new=TRUE)
         plot(sub.R0$day, sub.R0$est, bty='n', type='l', lwd=2, col='red', xlim=range(x.base), xaxt='n', xlab='', ylim=c(0, R0.max), yaxt='n', ylab='') 
         #points(sub.R0$day, sub.R0$lower, col='red', cex=0.2)
         #points(sub.R0$day, sub.R0$upper, col='red', cex=0.2)
         lines(sub.R0$day, sub.R0$lower, lwd=1, lty=2, col='red')
         lines(sub.R0$day, sub.R0$upper, lwd=1, lty=2, col='red')
         #polygon(c(sub.R0$day, sub.R0$day), c(sub.R0$lower, sub.R0$upper), col='lightgrey')
         axis(4, at=y.tick, labels=y.value, col='red')
         mtext('Effective R', side = 4, line = -2, outer = F, adj = 0.5, padj = 0, cex = 1.0)
         abline(h=1, lty=1, col='orange')
         if(day.growth.start+shift-inc.value[i] >= sub.R0$day[1])
         {
            abline(v=day.growth.start+shift-inc.value[i], lty=1, col='orange')
         }  else  abline(v=sub.R0$day[1], lty=1, col='orange')   
         abline(v=day.peak+shift-inc.value[i], lty=1, col='orange')
      }
   }
}

senplot.effective.R0 <- function(cases, location, shift, day.growth.start, day.peak, x.tick, x.value, cap.quantile, day.left.truncate)
{
   #cases<-girardot; location<-'girardot'; cap.quantile<-0.9; shift<-50; x.legend<-130; y.legend<-12; size<-1 
   path.out <- paste('C:/research/TranStat/v5/', location, '/overall/reporting_bias/0.1/2wk/', sep='')
   R0.a1 <- read.table(paste(path.out, 'output_R0_1.txt', sep=''), header=FALSE)
   colnames(R0.a1)<-c('inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
   R0.a1$day <- R0.a1$day - 3
   R0.a1 <- subset(R0.a1, day >= day.left.truncate)
   path.out <- paste('C:/research/TranStat/v5/', location, '/overall/reporting_bias/0.1/4wk/', sep='')
   R0.a2 <- read.table(paste(path.out, 'output_R0_1.txt', sep=''), header=FALSE)
   colnames(R0.a2)<-c('inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
   R0.a2$day <- R0.a2$day - 3
   R0.a2 <- subset(R0.a2, day >= day.left.truncate)
   path.out <- paste('C:/research/TranStat/v5/', location, '/overall/reporting_bias/0.1/6wk/', sep='')
   R0.a3 <- read.table(paste(path.out, 'output_R0_1.txt', sep=''), header=FALSE)
   colnames(R0.a3)<-c('inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
   R0.a3$day <- R0.a3$day - 3
   R0.a3 <- subset(R0.a3, day >= day.left.truncate)
   path.out <- paste('C:/research/TranStat/v5/', location, '/overall/reporting_bias/0.3/2wk/', sep='')
   R0.b1 <- read.table(paste(path.out, 'output_R0_1.txt', sep=''), header=FALSE)
   colnames(R0.b1)<-c('inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
   R0.b1$day <- R0.b1$day - 3
   R0.b1 <- subset(R0.b1, day >= day.left.truncate)
   path.out <- paste('C:/research/TranStat/v5/', location, '/overall/reporting_bias/0.3/4wk/', sep='')
   R0.b2 <- read.table(paste(path.out, 'output_R0_1.txt', sep=''), header=FALSE)
   colnames(R0.b2)<-c('inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
   R0.b2$day <- R0.b2$day - 3
   R0.b2 <- subset(R0.b2, day >= day.left.truncate)
   path.out <- paste('C:/research/TranStat/v5/', location, '/overall/reporting_bias/0.3/6wk/', sep='')
   R0.b3 <- read.table(paste(path.out, 'output_R0_1.txt', sep=''), header=FALSE)
   colnames(R0.b3)<-c('inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
   R0.b3$day <- R0.b3$day - 3
   R0.b3 <- subset(R0.b3, day >= day.left.truncate)
   
   R0.est <- c(R0.a1$est, R0.a2$est, R0.a3$est, R0.b1$est, R0.b2$est, R0.b3$est)
   R0.max<-as.numeric(quantile(R0.est, probs=cap.quantile))
   y <- R0.est
   y.tick<-pretty(y[y<R0.max])
   y.value<-as.character(signif(y.tick,2))

   cases$day <- cases$day + shift
   id.inc <- unique(R0.Tri$inc)
   id.inf <- unique(R0.Tri$inf)
   inc.name<-c('Short', 'Medium', 'Long')
   inc.value <- c(4.3, 5, 5.7)
   inf.name<-c('Short', 'Medium', 'Long')
   inf.value <- c(14.5, 17, 20.5)
   par(mfrow=c(3,3), mar = c(6, 4, 4, 2) + 0.1, xpd=F)
   for(i in 1:length(id.inc))
   {
      for(j in 1:length(id.inf))
      {
         par(mar = c(6, 4, 4, 2) + 0.1, xpd=F)
         sub.R0.a1 <- subset(R0.a1, inc==id.inc[i] & inf==id.inf[j], select=c(day, est))
         sub.R0.a2 <- subset(R0.a2, inc==id.inc[i] & inf==id.inf[j], select=c(day, est))
         sub.R0.a3 <- subset(R0.a3, inc==id.inc[i] & inf==id.inf[j], select=c(day, est))
         sub.R0.b1 <- subset(R0.b1, inc==id.inc[i] & inf==id.inf[j], select=c(day, est))
         sub.R0.b2 <- subset(R0.b2, inc==id.inc[i] & inf==id.inf[j], select=c(day, est))
         sub.R0.b3 <- subset(R0.b3, inc==id.inc[i] & inf==id.inf[j], select=c(day, est))
         tmp <- fill.dates(cases)
         x<-tmp$day
         x.base<-c(x-0.5, x+0.5)
         k<-order(x.base)
         x.base<-x.base[k]
         y<-rep(tmp$count,each=2)
         plot(x.base,y, bty='n', ylim=c(0, max(y)), type='l', lty=1, lwd=1, col='grey', xaxt='n', xlab='', ylab='',
              main=paste('Mean Serial Interval = ', inc.value[i]+inf.value[j], ' Days', sep=''))
         mtext('Case Number', side = 2, line = -2, outer = F, adj = 0.5, padj = 0, cex = 1.0)
         axis(1, at=x.tick, labels=F, col=1)
         mtext('Date', side = 1, line = 3, outer = F, adj = 0.5, padj = 0, cex = 0.8)
         text(x.tick, par("usr")[3]-max(y)/15, srt=30, adj=1, labels=x.value, xpd=T, cex=0.8)
         par(new=TRUE)
         plot(sub.R0.a2$day, sub.R0.a2$est, bty='n', type='l', lwd=1.5, col='red', xlim=range(x.base), xaxt='n', xlab='', ylim=c(0, R0.max), yaxt='n', ylab='') 
         lines(sub.R0.a3$day, sub.R0.a3$est, lwd=1.5, lty=2, col='red')
         lines(sub.R0.a1$day, sub.R0.a1$est, lwd=2, lty=3, col='red')
         lines(sub.R0.b2$day, sub.R0.b2$est, lwd=1.5, lty=1, col='darkgreen')
         lines(sub.R0.b3$day, sub.R0.b3$est, lwd=1.5, lty=2, col='darkgreen')
         lines(sub.R0.b1$day, sub.R0.b1$est, lwd=2, lty=3, col='darkgreen')
         axis(4, at=y.tick, labels=y.value, col='red')
         mtext('Effective R', side = 4, line = -2, outer = F, adj = 0.5, padj = 0, cex = 1.0)
         abline(h=1, lty=1, col='orange')
         if(day.growth.start+shift-inc.value[i] >= sub.R0.a3$day[1])
         {
            abline(v=day.growth.start+shift-inc.value[i], lty=1, col='orange')
         }  else  abline(v=sub.R0.a3$day[1], lty=1, col='orange')   
         abline(v=day.peak+shift-inc.value[i], lty=1, col='orange')
         #legend(x.legend, y.legend, legend=c('2 weeks', '4 weeks', '6 weeks'), bty='n',
         #       lty=c(3,2,1), lwd=c(1,1,1), col=c('red', 'red', 'red'), cex=size, text.width=width)
      }
   }
}

plot.single.effective.R0 <- function(cases, R0.Tri, fit, bias.base, bias.cut.day, bias.span.lower, bias.span.upper, shift, day.growth.start, day.peak, x.tick, x.value, cap.quantile, main.title)
{
   #cases<-sanandres; cap.quantile<-1.0; day.growth.start<-25; shift<-50 
   R0.max<-as.numeric(quantile(R0.Tri$upper, probs=cap.quantile))
   y <- c(R0.Tri$lower, R0.Tri$est, R0.Tri$upper)
   y.tick<-pretty(y[y<R0.max])
   y.value<-as.character(signif(y.tick,2))

   n <- max(cases$day) - min(cases$day) + 1
   rescale <- data.frame(day=min(cases$day):max(cases$day), scale=rep(0,n))
   if(is.null(bias.cut.day))
   {
      rescale$scale <- rep(1,n)
   } else
   {   
      lower <- bias.cut.day - bias.span.lower
      upper <- bias.cut.day + bias.span.upper
      rescale$scale[rescale$day < lower] <- bias.base
      k<-which(rescale$day >= lower & rescale$day <= upper)
      if(length(k) > 0)  rescale$scale[k] <- bias.base + (1-bias.base) * (rescale$day[k] - lower)/(upper - lower)
      rescale$scale[rescale$day > upper] <- 1
   }
   rescale$day <- rescale$day + shift
   my.fit <- merge(fit, rescale, by='day', all.x=TRUE, sort=FALSE)
   my.fit <- my.fit[order(my.fit$inc, my.fit$inf, my.fit$day), ]
   cases$day <- cases$day + shift
   id.inc <- unique(R0.Tri$inc)
   id.inf <- unique(R0.Tri$inf)
   inc.name<-c('Short', 'Medium', 'Long')
   inc.value <- c(4.3, 5, 5.7)
   inf.name<-c('Short', 'Medium', 'Long')
   inf.value <- c(14.5, 17, 20.5)
   for(i in 2:2)
   {
      for(j in 2:2)
      {
         par(mar = c(6, 4, 4, 2) + 0.1, xpd=F)
         sub.R0 <- subset(R0.Tri, inc==id.inc[i] & inf==id.inf[j], select=c(day, est, lower, upper))
         sub.fit <- subset(my.fit, inc==id.inc[i] & inf==id.inf[j], select=c(day, at_risk, obs, pred, lower, upper, scale))
         tmp <- fill.dates(cases)
         tmp <- merge(tmp, sub.R0, by='day', all.x=TRUE)
         x<-tmp$day
         x.base<-c(x-0.5, x+0.5)
         k<-order(x.base)
         x.base<-x.base[k]
         y<-rep(tmp$count,each=2)
         plot(x.base,y, bty='n', ylim=c(0, max(c(y, sub.fit$upper * sub.fit$scale))), type='l', lty=1, lwd=1, col='darkgrey', xaxt='n', xlab='', ylab='',
              main=main.title)
         mtext('Case Number', side = 2, line = -2, outer = F, adj = 0.5, padj = 0, cex = 1.0)
         axis(1, at=x.tick, labels=F, col=1)
         mtext('Date', side = 1, line = 3, outer = F, adj = 0.5, padj = 0, cex = 0.8)
         text(x.tick, par("usr")[3]-max(y)/15, srt=30, adj=1, labels=x.value, xpd=T, cex=0.8)
         lines(sub.fit$day, sub.fit$pred * sub.fit$scale, lwd=2, lty=1, col='darkgreen') 
         lines(sub.fit$day, sub.fit$lower * sub.fit$scale, lwd=1, lty=2, col='darkgreen')
         lines(sub.fit$day, sub.fit$upper * sub.fit$scale, lwd=1, lty=2, col='darkgreen')
         par(new=TRUE)
         plot(sub.R0$day, sub.R0$est, bty='n', type='l', lwd=2, col='red', xlim=range(x.base), xaxt='n', xlab='', ylim=c(0, R0.max), yaxt='n', ylab='') 
         lines(sub.R0$day, sub.R0$lower, lwd=1, lty=2, col='red')
         lines(sub.R0$day, sub.R0$upper, lwd=1, lty=2, col='red')
         axis(4, at=y.tick, labels=y.value, col='red')
         mtext('Effective R', side = 4, line = -2, outer = F, adj = 0.5, padj = 0, cex = 1.0)
         abline(h=1, lty=1, col='orange')
         if(day.growth.start+shift-inc.value[i] >= sub.R0$day[1])
         {
            abline(v=day.growth.start+shift-inc.value[i], lty=1, col='orange')
         }  else  abline(v=sub.R0$day[1], lty=1, col='orange')   
         abline(v=day.peak+shift-inc.value[i], lty=1, col='orange')
      }
   }
}

primary.effective.R0 <- function(girardot, sanandres)
{
   n.wk <- 4
   shift <- 50
   par(mfrow=c(2,1), mar = c(6, 4, 4, 2) + 0.1, xpd=F)

   day.growth.start<-25
   day.peak<-sanandres$day[which.max(sanandres$count)]
   bias.base<-0.1; bias.cut.day<-25
   bias.span.lower <-0; bias.span.upper <- n.wk * 7

   path.out <- paste('C:/research/TranStat/v5/sanandres/overall/reporting_bias/0.1/4wk/', sep='')
   R0.Tri <- read.table(paste(path.out, 'output_R0_1.txt', sep=''), header=FALSE)
   colnames(R0.Tri)<-c('inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
   R0.Tri$day <- R0.Tri$day - 3
   R0.Tri <- subset(R0.Tri, day >= 60 & day <= 165)

   x.value<-c('06SEP2015', '01OCT2015', '15OCT2015', '01NOV2015', '15NOV2015', '01DEC2015', '15DEC2015', '01JAN2016', '15JAN2016', '30JAN2016') 
   x.date<-as.Date(x.value, '%d%b%Y')
   x.tick<-as.numeric(x.date - as.Date("2015-09-05"))+shift
   
   fit <- read.table(paste(path.out, 'output_fitted_1.txt', sep=''), header=FALSE)
   colnames(fit)<-c('inc', 'inf', 'day', 'comm', 'at_risk', 'obs', 'pred')
   fit$lower <- fit$upper <- rep(0,nrow(fit))
   k<-which(fit$pred >0)
   if(length(k) > 0)
   {
      p <- fit$pred[k] / fit$at_risk[k]
      fit$lower[k] <- qbinom(rep(0.025, length(k)), size=fit$at_risk[k], prob=p, lower.tail=TRUE)
      fit$upper[k] <- qbinom(rep(0.025, length(k)), size=fit$at_risk[k], prob=p, lower.tail=FALSE)
   }   
   plot.single.effective.R0(sanandres, R0.Tri, fit, bias.base, bias.cut.day, bias.span.lower, bias.span.upper, 
                     shift, day.growth.start, day.peak, x.tick, x.value, 1.0, '(A) San Andres, Colombia')
   day.growth.start<-1
   day.peak<-girardot$day[which.max(girardot$count)]
   bias.base<-0.1; bias.cut.day<-1
   bias.span.lower <- 0; bias.span.upper <- n.wk * 7

   path.out <- paste('C:/research/TranStat/v5/girardot/overall/reporting_bias/0.1/4wk/', sep='')
   R0.Tri <- read.table(paste(path.out, 'output_R0_1.txt', sep=''), header=FALSE)
   colnames(R0.Tri)<-c('inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
   R0.Tri$day <- R0.Tri$day - 3
   R0.Tri <- subset(R0.Tri, day >= 60)

   x.value<-c('19OCT2015', '01NOV2015', '15NOV2015', '01DEC2015', '15DEC2015', '01JAN2016', '15JAN2016') 
   x.date<-as.Date(x.value, '%d%b%Y')
   x.tick<-as.numeric(x.date - as.Date("2015-10-18"))+shift
   fit <- read.table(paste(path.out, 'output_fitted_1.txt', sep=''), header=FALSE)
   colnames(fit)<-c('inc', 'inf', 'day', 'comm', 'at_risk', 'obs', 'pred')
   fit$lower <- fit$upper <- rep(0,nrow(fit))
   k<-which(fit$pred >0)
   if(length(k) > 0)
   {
      p <- fit$pred[k] / fit$at_risk[k]
      fit$lower[k] <- qbinom(rep(0.025, length(k)), size=fit$at_risk[k], prob=p, lower.tail=TRUE)
      fit$upper[k] <- qbinom(rep(0.025, length(k)), size=fit$at_risk[k], prob=p, lower.tail=FALSE)
   } 

   
   plot.single.effective.R0(girardot, R0.Tri, fit, bias.base, bias.cut.day, bias.span.lower, bias.span.upper, 
                     shift, day.growth.start, day.peak, x.tick, x.value, 0.9, '(B) Girardot, Colombia')
}

# Imperial college's package
fit.for.plot <- function(cases, start.time, stop.time, SI.mean, SI.sd, main.text)
{
   #cases<-girardot; start.time<-8:67; stop.time<-14:73; SI.mean<-c(10,15,20); SI.sd<-c(3,3,3); main.text<-'Girardot, Columbia'
   R.mean <- R.lower <- R.upper <- NULL
   for(i in 1:length(SI.mean))
   {
      fit<-EstimateR(cases$count, T.Start=start.time, T.End=stop.time, method=c("ParametricSI"),
                     Mean.SI=SI.mean[i], Std.SI=SI.sd[i], plot=FALSE)
      R.mean <- rbind(R.mean, fit$R[,3])
      R.lower <- rbind(R.lower, fit$R[,5])
      R.upper <- rbind(R.upper, fit$R[,11])
   }
   R.max <- max(R.upper, na.rm=TRUE)
   #par(mfrow=c(2,1))
   plot(stop.time, R.mean[1,], type='n', xlim=c(0,nrow(cases)), ylim=c(0, R.max), xaxt='n', xlab='', ylab='R', main=main.text)
   k<-which(!is.na(R.upper[1,]) & !is.na(R.lower[1,]))
   polygon(c(rev(stop.time[k]), stop.time[k]), c(rev(R.upper[1,k]), R.lower[1,k]), col = 'grey80', border = NA)
   k<-which(!is.na(R.upper[2,]) & !is.na(R.lower[2,]))
   polygon(c(rev(stop.time[k]), stop.time[k]), c(rev(R.upper[2,k]), R.lower[2,k]), col = 'grey80', border = NA)
   k<-which(!is.na(R.upper[3,]) & !is.na(R.lower[3,]))
   polygon(c(rev(stop.time[k]), stop.time[k]), c(rev(R.upper[3,k]), R.lower[3,k]), col = 'grey80', border = NA)
   lines(stop.time, R.mean[1,], lwd=1.5, lty=1, col='green')
   lines(stop.time, R.mean[2,], lwd=1.5, lty=2, col='red')
   lines(stop.time, R.mean[3,], lwd=1.5, lty=3, col='blue')
   legend("topright", legend=paste('Mean SI: ', SI.mean, ' days', sep=''),
          lty=c(1,2,3), lwd=c(2,2,2), col=c('green', 'red', 'blue'), text.width=30)
   x<-1:nrow(cases)
   x<-c(x-0.5, x+0.5)
   k<-order(x)
   x<-x[k]
   y<-rep(cases$count,each=2)
   plot(x,y, ylim=c(0, max(y)), type='l', lty=1, lwd=1.5, xlab='Day', ylab='Case Number')
}   
