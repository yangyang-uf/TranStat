setwd('/Users/yy70876/teach/TranStat/Examples/Indonesia')
pop<-read.table("raw_data.dat", header=F)
names(pop)<-c('id', 'village', 'hh', 'gender', 'age', 'lab', 'day_ill', 'day_hospital', 'day_death')
m<-nrow(pop)
pop$id <- pop$id - 1
k<-which(pop$day_hospital == -1)
pop$day_hospital[k] <- Inf
k<-which(pop$day_death == -1)
pop$day_death[k] <- Inf
shift<-7
epidemic_end<-30
# the order of individuals in the raw data is
# 0   1.A (index case) 
# 1   1.B (son of index case) 
# 2   1.C (son of index case) 
# 3   1.D (son of index case) 
# 4   1.E (grandma) 
# 5   1.F (daughter of index case) 
# 6   2.A (Mother)
# 7   2.B (Father)
# 8   2.C (Daughter)
# 9   2.D (Son)
# 10  2.E (Daughter)
# 11  3.A (Father)
# 12  3.B (Mother)
# 13  3.C (Son)
# 14  3.D (Son)
# 15  4.A (Father)
# 16  4.B (Mother)
# 17  4.C (Son)
# 18  4.D (Son)
# 19  5.A (Fiance of the dauter of the index case)
# 20  6.A (Brother of the index case)

#c2p contact
c2p<-NULL
for( i in 1:m)
{
   c2p<-rbind(c2p, c(i-1, 1, epidemic_end + shift, 0, 0.0, 0))
}
c2p<-as.data.frame(c2p)
names(c2p)<-c('id', 'start', 'stop', 'contact_type', 'weight', 'ignore')
write.table(c2p, file = "TranStat/c2p_contact.dat", append = FALSE, sep='   ', eol = "\n", row.names = F, col.names = F)


# individual-level between-household contact
p2p<-NULL
p2p<-rbind(p2p, c(6, 10, 6, 0, 0, 0, 0))  # 2.A with 1.A
p2p<-rbind(p2p, c(6, 9, 8, 0, 0, 0.0, 0)) # 2.C with 1.A
p2p<-rbind(p2p, c(6, 6, 11, 0, 0, 0.0, 0)) # 3.A qith 1.A
p2p<-rbind(p2p, c(1, 9, 13, 0, 0, 0.0, 0)) # 3.C with 1.A
p2p<-rbind(p2p, c(6, 6, 15, 0, 0, 0.0, 0)) # 4.A with 1.A
p2p<-rbind(p2p, c(6, 6, 16, 0, 0, 0.0, 0)) # 4.B with 1.A
p2p<-rbind(p2p, c(6, 6, 17, 0, 0, 0.0, 0)) # 4.C with 1.A
p2p<-rbind(p2p, c(6, 6, 18, 0, 0, 0.0, 0)) # 4.D with 1.A
p2p<-rbind(p2p, c(6, 6, 19, 0, 0, 0.0, 0)) # Fiance of 1.F with 1.A

# individual-level within-household contact
for(i in 1:(m-1))
{
   for(j in (i+1):m)
   {
      if(pop$hh[i] == pop$hh[j])
      {
         # p2p exposure should be no more than hospitalization or death date or the last day of the pidemic (for which we assume day 30)
         start<-1
         stop<-min(c(pop$day_hospital[i], pop$day_death[i], pop$day_hospital[j], pop$day_death[j], 30)) 
         p2p<-rbind(p2p, c(start, stop, pop$id[i], pop$id[j], 0, 0.0, 0))
      }
   }
}
p2p<-as.data.frame(p2p)
names(p2p)<-c('start', 'stop', 'i', 'j', 'contact_type', 'weight', 'ignore')
p2p$start<-p2p$start+shift
p2p$stop<-p2p$stop+shift
write.table(p2p, file = "TranStat/p2p_contact.dat", append = FALSE, sep='   ', eol = "\n", row.names = F, col.names = F)

pop$community <- 0
pop$preimmune <- 0
pop$infection<-as.numeric(pop$day_ill>0)
pop$symptom <- as.numeric(pop$day_ill != -1)
k<-which(pop$day_ill > 0)
pop$day_ill[k]<-pop$day_ill[k] + shift
pop$exit <- 0
pop$day_exit <-epidemic_end
k<-which(pop$day_hospital < pop$day_exit)
if(length(k)>0)  pop$day_exit[k] <- pop$day_hospital[k]
k<-which(pop$day_death < pop$day_exit)
if(length(k)>0)  pop$day_exit[k] <- pop$day_death[k]
pop$day_exit <- pop$day_exit + shift
pop$index <- 0
pop$index[1] <- 1
pop$u_mode <- 0
pop$q_mode <- 0
pop$weight <- 1
pop$ignore <- 0
pop<-subset(pop, select=c('id', 'community', 'preimmune', 'infection', 'symptom', 'day_ill', 
                          'exit', 'day_exit', 'index', 'u_mode', 'q_mode', 'weight',  'ignore'))
write.table(pop, file = "TranStat/pop.dat", append = FALSE, sep='   ', eol = "\n", row.names = F, col.names = F)

write.table(matrix(c(0, 1, epidemic_end + shift), nrow=1), file = "TranStat/community.dat", append = FALSE, 
            sep='   ', eol = "\n", row.names = F, col.names = F)

