setwd('/Users/yy70876/teach/TranStat/Examples/Guangzhou')
fit.SAR <- read.table('SAR/output_goodness.txt', header=FALSE)
colnames(fit.SAR)<-c('serial', 'inc', 'inf', 'day', 'obs', 'pred')
fit.OR <- read.table('OR/output_goodness.txt', header=FALSE)
colnames(fit.OR)<-c('serial', 'inc', 'inf', 'day', 'obs', 'pred')

pdf('Goodness_Of_Fit.pdf', width=12, height=10)
par(mfrow=c(2,1))
plot(fit.SAR$day, fit.SAR$obs, type='p', pch=1, col='red', 
     xlab='Day', ylab='Number of Infections', 
     main='Goodness of fit: estimating SAR')
points(fit.SAR$day, fit.SAR$pred, pch=2, col='darkgreen')
legend('topright', legend=c('Obs', 'Pred'), pch=c(1,2), col=c('red', 'darkgreen'))

plot(fit.OR$day, fit.OR$obs, type='p', pch=1, col='red', 
     xlab='Day', ylab='Number of Infections', 
     main='Goodness of fit: estimating Odds Ratios')
points(fit.OR$day, fit.OR$pred, pch=2, col='darkgreen')
legend('topright', legend=c('Obs', 'Pred'), pch=c(1,2), col=c('red', 'darkgreen'))
dev.off()

