rm(list=ls())

##Set the Working Directory##
setwd('/Users/yy70876/teach/TranStat/Examples/SanAndres')
path.transtat.data <- '/Users/yy70876/teach/TranStat/Examples/SanAndres/TranStat/' 
source('EstimationR.R')
source('functions.R')

load('sanandres.RData')

pop.gen(sanandres, demo.sanandres, idx.cut.day=10, contact.cut.day=NULL, 
        bias.base=0.1, bias.cut.day=25, bias.span=28, shift=50, 
        path=path.transtat.data, type='overall')

