setwd('/Users/yy70876/teach/TranStat/Examples/SanAndres')
source('functions.R')
shift <- 50

###############################################################################
# San Andres, Columbia
###############################################################################

n.wk <- 4
day.growth.start<-25
bias.base<-0.1; bias.cut.day<-25
bias.span <- n.wk * 7
load(file='sanandres.RData')
day.peak<-sanandres$day[which.max(sanandres$count)]
R0.Tri <- read.table('TranStat/output_R0.txt', header=FALSE)
colnames(R0.Tri)<-c('serial', 'inc', 'inf', 'day', 'est', 'std', 'lower', 'upper')
#R0.Tri$day <- R0.Tri$day - 3 # In TranStat output, a given day is matched to average R in the previous week of (including) the day.
                             # It is more reasonable to assign the R value to 3 days before the given day.
k <- which(is.na(R0.Tri$upper))
if(length(k)>0)  R0.Tri$upper[k] <- Inf
x.value<-c('06SEP2015', '01OCT2015', '15OCT2015', '01NOV2015', '15NOV2015', '01DEC2015', '15DEC2015', '01JAN2016', '15JAN2016', '30JAN2016') 
x.date<-as.Date(x.value, '%d%b%Y')
x.tick<-as.numeric(x.date - as.Date("2015-09-05"))+shift

R0.Tri <- subset(R0.Tri, day >= 69 & day <= 185)
fit <- read.table('TranStat/output_goodness.txt', header=FALSE)
colnames(fit)<-c('serial', 'inc', 'inf', 'day', 'at_risk', 'obs', 'pred')
fit$lower <- fit$upper <- rep(0,nrow(fit))
k<-which(fit$pred >0)
if(length(k) > 0)
{
   p <- fit$pred[k] / fit$at_risk[k]
   fit$lower[k] <- qbinom(rep(0.025, length(k)), size=fit$at_risk[k], prob=p, lower.tail=TRUE)
   fit$upper[k] <- qbinom(rep(0.025, length(k)), size=fit$at_risk[k], prob=p, lower.tail=FALSE)
}   
pdf('Rt_and_Goodness_Of_Fit.pdf', width=12, height=10)
plot.effective.R0(sanandres, R0.Tri, fit, bias.base, bias.cut.day, bias.span, shift, 
                  day.growth.start, day.peak, x.tick, x.value, 0.95)
dev.off()


